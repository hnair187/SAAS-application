def hello():
    print("Function Creation")